import os
import gradio as gr
from uuid import uuid4
from single_pile.main import single_pile_main
from unreinforced_footing.main import footing_main

current_path = os.path.dirname(os.path.abspath(__file__))
os.environ['DOCKER_VOLUME_DIRECTORY'] = str(current_path)


def task_accordion():
    # 创建可折叠的界面元素
    with gr.Accordion("📦 Task setting", open=False, visible=True):
        task = gr.Dropdown(
            choices=["Shallow foundation"],
            value="Shallow foundation",
            label="Tasks")

        # code = gr.Radio(
        #     choices=["国标", "美标", '欧标'],
        #     label="规范选择")

        save_name = gr.Textbox(
            lines=1,  # 一行
            label="Designed filename",
            interactive=True,
            value="Output",
            placeholder="Please enter the file name you wish to save...",  # 底纹占位符
            show_label=True,
            max_lines=1,
        )
        code = ''
    return task, code, save_name


def model_accordion():
    # 创建可折叠的界面元素
    with gr.Accordion("📦 Model setting", open=False, visible=True):
        model_name = gr.Dropdown(
            choices=["gpt-4o", "o1"],
            value="gpt-4o",
            label="Model setting")

        api_key = gr.Textbox(
            lines=1,  # 一行
            label="API KEY",
            value="sk-wnGm6JEoohAdAM3HB002F10e16Ae4d289e62D19a7f1aA474",
            interactive=True,
            placeholder="Please input your API KEY...",  # 底纹占位符
            show_label=True,
            max_lines=1,
        )

        temperature = gr.Slider(
            minimum=0.0,
            maximum=1.0,
            value=0.9,
            step=0.01,
            interactive=True,  # 允许用户与滑动条交互
            label="Temperature"
        )  # 第一个参数为temperature，最小值为0，最大值为1.0，默认值为0.9，步长为0.05.

        top_p = gr.Slider(
            minimum=0.1,
            maximum=1.0,
            value=0.9,
            step=0.01,
            interactive=True,
            label="Top_p",
        )  # 第二个参数为top_p，最小值为0，最大值为1.0，默认值为0.9，步长为0.01.

        max_tokens = gr.Slider(
            minimum=1024,
            maximum=4096,
            value=2048,
            step=32,
            interactive=True,
            label="Max tokens",
        )  # 第三个参数为max token，最小值为64，最大值为4096，默认值为2048，步长为32.

        session_id = gr.Textbox(
            value=uuid4,
            interactive=False,
            visible=False,
        )  # 创建一个名为session_id的文本框，作为聊天的唯一标识。

    # 补充过长模型名称
    if model_name == "glm-4":
        model_name = "glm-4-0520"

    return temperature, top_p, session_id, max_tokens, api_key, model_name


def run_chat(
        message: dict,
        history,
        model_name: str,
        api_key: str,
        task: str,
        temperature: float,
        top_p: float,
        max_tokens: int,
        output_name: str,
):
    # if task == "单桩设计":
    #     output_path = "./output/" + output_name + ".json"
    #     file_path = "./output/" + output_name + ".png"
    #     structured_data, index = single_pile_main(message["text"], model_name, max_tokens, top_p, api_key, temperature,
    #                                               output_path, file_path)
    #
    #     if not index:
    #         return "提取结果有一些问题，请重试！"
    #     else:
    #         if len(message['files']) == 0:
    #             A = (f"Pile shape: {structured_data['Requirement']['Pile_shape']}\n"
    #                  f"Pile length: {structured_data['Pile']['Pile_length']: .02f} m\n"
    #                  f"Pile diameter: {structured_data['Pile']['Pile_diameter']: .02f} m\n")
    #             B = C = ""
    #             D = (
    #                 f"Steel reinforcement: {structured_data['Reinforcement']['Num']}{chr(934)}{structured_data['Reinforcement']['Diameter']}")
    #             try:
    #                 if structured_data["R_capacity"]["R_1"] == structured_data["R_capacity"]["R_2"]:
    #                     B = f"Capacity: {structured_data['R_capacity']['R_1']: .02f} kN\n"
    #                 else:
    #                     B = f"Capacity: {structured_data['R_capacity']['R_1']: .02f} kN & Capacity: {structured_data['R_capacity']['R_1']: .02f} kN\n"
    #             except:
    #                 pass
    #
    #             try:
    #                 C = f"Settlement: {structured_data['Settlement']: .02f} mm\n"
    #             except:
    #                 pass
    #             # return A+B+C+D
    #             return {"path": file_path}


    if task == "Shallow foundation":
        output_path = "./output/" + output_name + ".json"
        file_path = "./output/" + output_name + ".png"

        if message["text"] == "":
            text = False
        else:
            text = message["text"]

        if len(message["files"]) == 0:
            image = False
        else:
            image = message["files"][0]["path"]

        structured_data, index = footing_main(model_name, api_key, temperature, top_p, max_tokens, image, text,
                                              output_path, file_path)

        if not index:
            return "提取结果有一些问题，请重试！"
        else:
            return {"path": file_path}
    else:
        structured_data = index = False


def chat_tab():
    with gr.Column(scale=1):  # 创造一列
        with gr.Row():  # 创造一行
            (
                temperature,
                top_p,
                session_id,
                max_tokens,
                api_key,
                model_name,
            ) = model_accordion()

        with gr.Row():  # 创造一行
            (
                task,
                code,
                output_path,
            ) = task_accordion()

    with gr.Column(scale=3):
        with gr.Blocks():
            gr.ChatInterface(
                fn=run_chat,
                multimodal=True,
                chatbot=gr.Chatbot(
                    height=620,  # 聊天机器人的高度
                    render=False,  # 不使用从右到左布局
                    show_label=False,
                    rtl=False,
                    placeholder="<font size='4'><strong>Intelligent Geotechnical design</strong><br>DESIGN FOR ANYTHING",
                    avatar_images=("./images/images_user_icon.png", "./images/images_bot_icon.png"),
                ),

                textbox=gr.MultimodalTextbox(
                    placeholder="Enter your design text or image...",
                    render=False,  # 不渲染文本框的内容
                    scale=7,  # 相对宽度为7个默认列
                    rtl=False,  # 不使用从右到左布局
                ),

                additional_inputs=[model_name,
                                   api_key,
                                   task,
                                   temperature,
                                   top_p,
                                   max_tokens,
                                   output_path],  # 传递额外参数给run_chat

                submit_btn=f"🔼 Submit",
                stop_btn="🔽 Stop",
                retry_btn="🔄 Retry",
                undo_btn="↩️ Backspace",
                clear_btn="🚮 Clean")


def main():
    with gr.Blocks(
            css="""
               footer {visibility: hidden}
               """,
            title="Auto-Design (Demo)",
    ) as demo:  # 添加css参数
        with gr.Row():
            with gr.Column(scale=2):
                gr.Image("images/Logo1.png", elem_id="banner-image", show_label=False)
                gr.Markdown("""    <p align="center">
                    <strong style="font-size: 24px;">Auto-Design</strong>
                </p>""")
        with gr.Row():
            chat_tab()
    return demo


def start_demo():
    demo = main()
    demo.queue().launch(show_api=False, share=True)


if __name__ == "__main__":
    start_demo()