import pandas as pd


def count_key_value_pairs(d):
    count = 0
    if isinstance(d, dict):
        for key, value in d.items():
            if isinstance(value, (str, float, int)):
                count += 1  # Count the key-value pair
            count += count_key_value_pairs(value)  # Recursively count nested key-value pairs
    elif isinstance(d, list):
        for item in d:
            count += count_key_value_pairs(item)  # Recursively count key-value pairs in list items
    return count


def compare_dicts(dict1, dict2):
    count = 0
    if isinstance(dict1, dict) and isinstance(dict2, dict):
        for key in dict1:
            if key in dict2:
                if dict1[key] != dict2[key]:
                    count += 1
                count += compare_dicts(dict1[key], dict2[key])
            else:
                count += 1
        for key in dict2:
            if key not in dict1:
                count += 1
    elif isinstance(dict1, list) and isinstance(dict2, list):
        for item1, item2 in zip(dict1, dict2):
            count += compare_dicts(item1, item2)
    else:
        if dict1 != dict2:
            count += 1
    return count


# 读取Excel文件
df = pd.read_excel('G:\\Paper2\\Data\\evaluation\\test.xlsx')
print(df)
# 假设两列分别是 'dict1' 和 'dict2'
dict1_col = 'Answer_a'
dict2_col = 'Answer_b'

# 初始化新列
df['count'] = None
df['difference'] = None

# 初始化计数器
total_differences = 0

# 遍历每一行
for index, row in df.iterrows():
    dict1 = row[dict1_col]
    dict2 = row[dict2_col]

    # 比较两个字典
    count = count_key_value_pairs(dict1)
    differences = compare_dicts(dict1, dict2)

    # 写入新列
    df.at[index, 'count'] = count
    df.at[index, 'difference'] = differences

# 保存修改后的Excel文件
df.to_excel('G:\\Paper2\\Data\\evaluation\\test.xlsx', index=False)

print(f"Total differences: {total_differences}")