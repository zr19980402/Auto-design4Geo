____________________
20250110-1221-44____________________
Error str 3-2: Subtask (capacity or settlement) is not a str or None.

