(1) Fill your API keys and model selection into file "run/config.json";

(2) Run file "run/design_main.py";

(3) For single LLM experiment, please revise file "workflow/LLM_workflow.py";

(4) For original LLM experiment, please run file "run/original_LLM.py".