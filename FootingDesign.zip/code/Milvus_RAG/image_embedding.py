from glob import glob
from towhee import pipe, ops, DataCollection
from pymilvus import connections, FieldSchema, CollectionSchema, DataType, Collection, utility
import numpy as np
from pathlib import Path


def read_images(image_insert_path):
    # List all files as the format of SRC
    to_insert = glob(image_insert_path)
    filtered_list = [file for file in to_insert if not file.endswith(".csv")]
    return filtered_list


def create_milvus_image_collection(dim, index_type, metric_type, nlist, image_collection_name):
    # Create milvus collection. Delete first if exists
    if utility.has_collection(image_collection_name):
        utility.drop_collection(image_collection_name)

    # Define fields (字段), ID, name...
    fields = [
        FieldSchema(name='path', dtype=DataType.VARCHAR, description='path to image', max_length=500, is_primary=True, auto_id=False),
        FieldSchema(name='embedding', dtype=DataType.FLOAT_VECTOR, description='image embedding vectors', dim=dim)
              ]

    # Define schema (模式), transfer fields to schema
    schema = CollectionSchema(fields=fields, description='reverse image search')

    # Define collection (集合)
    collection = Collection(name=image_collection_name, schema=schema)

    index_params = {
        'metric_type': metric_type,
        'index_type': index_type,
        'params': {"nlist": nlist}  # The number of cells
    }
    collection.create_index(field_name='embedding', index_params=index_params)  # Create index with embedding
    return collection


def p_image_embedding(model, device):
    # Embedding pipeline, stream
    p_embed = (
        pipe.input('img_path')
            .map('img_path', 'img', ops.image_decode('rgb'))
            .map('img', 'vec', ops.image_embedding.timm(model_name=model, device=device))
            .map('vec', 'vec', lambda x: x / np.linalg.norm(x, axis=0))
    )
    return p_embed


def p_image_inserting(model, host, port, device, image_collection_name):
    p_embed = p_image_embedding(model, device)

    # Embedding pipeline, stream
    p_insert = (
            p_embed.map(('img_path', 'vec'), 'mr', ops.ann_insert.milvus_client(
                        host=host,
                        port=port,
                        collection_name=image_collection_name
                        ))
              .output('mr')
    )
    return p_insert


def create_image_collection(dim, model, index_type, metric_type, nlist, image_insert_path, image_collection_name, device, host, port):
    # List all files as the format of SRC
    to_insert = read_images(image_insert_path)

    # Create collection
    image_collection = create_milvus_image_collection(dim, index_type, metric_type, nlist, image_collection_name)
    print(f'A new collection created: {image_collection}')

    # Insert processing
    p_insert = p_image_inserting(model, host, port, device, image_collection_name)
    for img_path in to_insert:
        p_insert(img_path)
    image_collection.flush()
    # The number of vectors currently stored in the collection
    print('Number of data inserted:', image_collection.num_entities)


def image_similarity_search(dim, model, top_k, index_type, metric_type, nlist, image_insert_path, image_collection_name, image_reconstruction, device, host, port):

    # Connect to Milvus service
    connections.connect("default", host=host, port=port)
    if not utility.has_collection(image_collection_name) or image_reconstruction:
        create_image_collection(dim, model, index_type, metric_type, nlist, image_insert_path, image_collection_name, device, host, port)

    # Load vector library
    collection = Collection(image_collection_name)
    collection.load()

    # Search pipeline
    p_embed = p_image_embedding(model, device)
    p_search_img = (p_embed.map('vec', ('search_res'), ops.ann_search.milvus_client(
        host=host, port=port, limit=top_k,
        collection_name=image_collection_name))
                    .map('search_res', ('pred'), lambda x: [str(Path(y[0]).resolve()) for y in x]).output('pred'))

    # Disconnect from Milvus
    connections.disconnect("default")
    return p_search_img


def img_prediction(image_dim, model, top_k, index_type, metric_type, nlist, image_insert_path, image_collection_name, image_reconstruction, device, host, port, search_image=False):
    # Return 2 more similar images back.
    p_search_img = image_similarity_search(image_dim, model, top_k, index_type, metric_type, nlist, image_insert_path, image_collection_name, image_reconstruction, device, host, port)
    img_pred = DataCollection(p_search_img(search_image))
    img_pred = img_pred[0]["pred"]
    # Return a list for predicted images, like [list]
    return {"text_id": False, "img_path": img_pred}

