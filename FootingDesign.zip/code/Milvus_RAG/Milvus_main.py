import os
import json
import subprocess
from Milvus_RAG.image_embedding import img_prediction
from Milvus_RAG.text_embedding import text_prediction
from Milvus_RAG.image_text_embedding import img_text_prediction

current_path = os.path.dirname(os.path.abspath(__file__))
config_path = current_path + "/Milvus_config/vec_config.json"
os.environ['DOCKER_VOLUME_DIRECTORY'] = str(current_path)

def read_config(config_file):
    with open(config_file, "r", encoding="utf-8") as f:
        config = json.load(f)
    # Model parameters and dimension of embedding extracted， changed with different models
    image_dim = config["image_dim"]
    text_dim = config["text_dim"]
    image_model = config["image_model_name"]
    text_model = config["text_model_name"]
    top_k = config["top_k"]
    index_type = config["index_type"]
    metric_type = config["metric_type"]
    nlist = config["nlist"]

    # Image parameters

    image_insert_path = current_path + "/data/" + config["image_path"] + "/" + "*.*"
    image_collection_name = config["image_collection_name"]  # The collection name in Milvus
    image_reconstruction = config["image_reconstruction"]  # Whether reconstruct vector library to images

    # Text parameters
    text_insert_path = current_path + "/data/" + config["text_path"] + "/" + "*.csv"
    text_collection_name = config["text_collection_name"]  # The collection name in Milvus
    text_reconstruction = config["text_reconstruction"]  # Whether reconstruct vector library to texts

    # Text parameters
    image_text_insert_path = current_path + "/data/" + config["image_text_path"] + "/" + "*.*"
    image_text_collection_name = config["image_text_collection_name"]  # The collection name in Milvus
    image_text_reconstruction = config["image_text_reconstruction"]  # Reconstruct vector library to texts and images

    # Default parameters
    device = None  # if None, use default device (cuda is enabled if available)
    host = '127.0.0.1'  # Local machine for Milvus
    port = '19530'  # Default for Milvus
    return image_dim, text_dim, text_model, image_model, top_k, index_type, metric_type, nlist, image_insert_path, image_collection_name, image_reconstruction, text_insert_path, text_collection_name, text_reconstruction, image_text_insert_path, image_text_reconstruction, image_text_collection_name, device, host, port


def total_prediction(config_file=config_path, search_image=False, search_text=False):
    # Input: Search_image is a path to image, search_text is a text content (str)
    # Output: Similar text's id and similar image's path []

    # Build command
    command = "docker-compose start"
    # Subprocess.run
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, cwd=current_path, stderr=subprocess.PIPE, text=True)
    print(result.stdout)
    print(result.stderr)

    # Read config
    image_dim, text_dim, text_model, image_model, top_k, index_type, metric_type, nlist, image_insert_path, image_collection_name, image_reconstruction, text_insert_path, text_collection_name, text_reconstruction, image_text_insert_path, image_text_reconstruction, image_text_collection_name, device, host, port = read_config(config_file)

    if search_image and not search_text:
        image_pred = img_prediction(image_dim, image_model, top_k, index_type, metric_type, nlist, image_insert_path, image_collection_name, image_reconstruction, device, host, port, search_image)
        return image_pred

    elif not search_image and search_text:
        text_pred = text_prediction(text_dim, text_model, top_k, index_type, metric_type, nlist, text_insert_path, text_collection_name, text_reconstruction, host, port, search_text)
        return text_pred

    elif search_image and search_text:
        image_text_pred = img_text_prediction(image_dim, text_dim, image_model, text_model, top_k, index_type, metric_type, nlist,  image_text_insert_path, image_text_reconstruction, image_text_collection_name, device, host, port, search_image, search_text)
        return image_text_pred
    else:
        pass

    # Build command
    command = "docker-compose stop"
    # Subprocess.run
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, cwd=current_path, stderr=subprocess.PIPE, text=True)
    print(result.stdout)
    print(result.stderr)