from Milvus_RAG.text_embedding import text_similarity_search
from Milvus_RAG.image_embedding import image_similarity_search
from towhee import DataCollection


def img_text_prediction(image_dim, text_dim, image_model, text_model, top_k, index_type, metric_type, nlist,  image_text_insert_path, image_text_reconstruction, image_text_collection_name, device, host, port, search_image=False, search_text=False):

    # Recall half of images and half of texts
    # top_k = int(top_k / 2)

    # Return the most similar images back.
    p_search_img = image_similarity_search(image_dim, image_model, top_k, index_type, metric_type, nlist, image_text_insert_path, image_text_collection_name, image_text_reconstruction, device, host, port)

    # Return a list for predicted images, like [list]
    img_pred = DataCollection(p_search_img(search_image))
    img_pred = img_pred[0]["pred"]

    # Return the most similar text back
    image_text_collection_name = image_text_collection_name + "_"
    p_search_text = text_similarity_search(text_dim, text_model, top_k, index_type, metric_type, nlist,  image_text_insert_path,  image_text_collection_name, image_text_reconstruction,host, port)
    text_pred = DataCollection(p_search_text(search_text))

    # Return id list, [list]
    function = lambda x: [_['id'] for _ in x]
    text_pred = function(text_pred)

    # Return {'text_id': [...], 'img_path': [...]}
    return {"text_id": text_pred, "img_path": img_pred}
