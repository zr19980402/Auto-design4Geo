import pandas as pd
from pymilvus import connections, FieldSchema, CollectionSchema, DataType, Collection, utility
from towhee import ops, pipe, DataCollection
import numpy as np
from glob import glob


def read_texts(text_path):
    # List all files as the format of SRC
    to_insert = glob(text_path)
    filtered_list = [file for file in to_insert if file.endswith(".csv")]

    if filtered_list:
        df = pd.read_csv(filtered_list[0])
        df_list = df.values.tolist()
        return df_list
    else:
        text = text_path
        return text


def cut_text_input(data):
    if isinstance(data, list):
        return int(data[0]), data[1]
    elif isinstance(data, str):
        return 0, data


def create_milvus_text_collection(dim, index_type, metric_type, nlist, text_collection_name):
    # Create collection
    if utility.has_collection(text_collection_name):
        utility.drop_collection(text_collection_name)

    fields = [FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=False),
             # FieldSchema(name="content", dtype=DataType.VARCHAR, max_length=2000),
              FieldSchema(name="vector", dtype=DataType.FLOAT_VECTOR, dim=dim)]
    schema = CollectionSchema(fields=fields, description="search text")
    collection = Collection(name=text_collection_name, schema=schema)

    index_params = {
        "metric_type": metric_type,
        "index_type": index_type,
        "params": {"nlist": nlist}
    }
    collection.create_index(field_name='vector', index_params=index_params)
    return collection


def p_text_embedding(model):
    # Embedding pipeline, stream
    p_embed = (
        pipe.input('data')
            .map('data',('id', 'df'), cut_text_input)
            .map('df', 'vec', ops.text_embedding.dpr(model_name=model))
            .map('vec', 'vec', lambda x: x / np.linalg.norm(x, axis=0))
    )
    return p_embed


def p_text_inserting(model, host, port, text_collection_name):
    # Embedding pipeline, stream
    p_embed = p_text_embedding(model)
    p_insert = (p_embed.map(('id', 'vec'), 'mr', ops.ann_insert.milvus_client(host=host, port=port, collection_name=text_collection_name)).output('mr'))

    return p_insert


def create_text_collection(dim, model, index_type, metric_type, nlist, text_insert_path, text_collection_name, host, port):
    # List all files as the format of SRC
    to_insert = read_texts(text_insert_path)

    # Create collection
    text_collection = create_milvus_text_collection(dim, index_type, metric_type, nlist, text_collection_name)
    print(f'A new collection created: {text_collection}')

    # Insert processing
    p_insert = p_text_inserting(model, host, port, text_collection_name)
    for _ in to_insert:
        p_insert(_)
    text_collection.flush()
    # The number of vectors currently stored in the collection
    print('Number of data inserted:', text_collection.num_entities)


def text_similarity_search(dim, model, top_k, index_type, metric_type, nlist, text_insert_path, text_collection_name, text_reconstruction, host, port):

    # Connect to Milvus service
    connections.connect("default", host=host, port=port)
    if not utility.has_collection(text_collection_name) or text_reconstruction:
        create_text_collection(dim, model, index_type, metric_type, nlist, text_insert_path, text_collection_name, host, port)

    # Load vector library
    collection = Collection(text_collection_name)
    collection.load()

    # Search pipeline
    p_embed = p_text_embedding(model)
    p_search_text = (p_embed.flat_map('vec', ('id', 'score'), ops.ann_search.milvus_client(host=host, port=port, limit=top_k, collection_name=text_collection_name)).output('id'))

    # Disconnect from Milvus
    connections.disconnect("default")
    return p_search_text


def text_prediction(text_dim, model, top_k, index_type, metric_type, nlist, text_insert_path, text_collection_name, text_reconstruction, host, port, search_text=False):
    # Return 2 more similar texts back
    p_search_text = text_similarity_search(text_dim, model, top_k, index_type, metric_type, nlist, text_insert_path, text_collection_name, text_reconstruction, host, port)
    text_pred = DataCollection(p_search_text(search_text))

    text_pred_ = list()
    # Return id list, [list]
    for item in text_pred:
        text_pred_ = item['id']

    return {"text_id": text_pred_, "img_path": False}